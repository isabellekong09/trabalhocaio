
 let produtos = ["Celuar", "Mouse", "Monitor", "Notebbok", "Impressora", "Teclado", "Telveisão", "Fone", "Webcam", "HD Externo"];
produtos[0]="Celular";
produtos[3]="Notebook";
produtos[6]="Televisão";
 
console.log(produtos);